# Installation
> `npm install --save @types/three`

# Summary
This package contains type definitions for three (https://threejs.org/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/three.

### Additional Details
 * Last updated: Thu, 16 Apr 2026 19:29:33 GMT
 * Dependencies: [@dimforge/rapier3d-compat](https://npmjs.com/package/@dimforge/rapier3d-compat), [@tweenjs/tween.js](https://npmjs.com/package/@tweenjs/tween.js), [@types/stats.js](https://npmjs.com/package/@types/stats.js), [@types/webxr](https://npmjs.com/package/@types/webxr), [fflate](https://npmjs.com/package/fflate), [meshoptimizer](https://npmjs.com/package/meshoptimizer)

# Credits
These definitions were written by [Josh Ellis](https://github.com/joshuaellis), and [Nathan Bierema](https://github.com/Methuselah96).
